#!/bin/bash

#First for CentOS  6 x86_64
cd /data/CentOS-6-x86_64/os/
rm -f *
cd /data/CentOS-repos/6/os/x86_64/Packages/

find . -mtime -7 ! -name '*.html' | grep  .rpm | cut -b 1-2 --complement >> /data/CentOS-6-x86_64/os/updates-list

          echo '===================================' >> /data/Scanned-Rpms-report
          echo 'CentOS 6 X86_64 OS' >> /data/Scanned-Rpms-report
          echo '===================================' >> /data/Scanned-Rpms-report

for i in $(cat /data/CentOS-6-x86_64/os/updates-list)
     do
        if clamscan $i
           then cp $i /data/CentOS-6-x86_64/os
          echo '===================================' >> /data/Scanned-Rpms-report
          echo $i '  has been uploaded' >> /data/Scanned-Rpms-report
          echo '===================================' >> /data/Scanned-Rpms-report
        else
        echo '===================================' >> /data/Scanned-Rpms-report
        echo $i ' Failed virus scan' >> /data/Scanned-Rpms-report
        echo '===================================' >> /data/Scanned-Rpms-report
        fi
     done
       if ls /data/CentOS-6-x86_64/os | grep rpm
          then 
          cd /data/CentOS-6-x86_64
          tar -cvf CentOS-6-x86_64-os.tar os
          chown owtuser1:owtuser1 CentOS-6-x86_64-os.tar
          mv CentOS-6-x86_64-os.tar /home/owt/priv/pickup
       fi


