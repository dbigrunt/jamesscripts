#!/bin/bash

#EPEL for Rhel 5 x86_64 tar 

cd /data/epel-x86_64/epel-rhel5/dl.fedoraproject.org/pub/

tar -cvf Epel-Rhel5-x86_64.tar epel

mv Epel-Rhel5-x86_64.tar /data/Tarballs/

