#!/bin/bash

#Centos 6.2 x86_64 OS tar 

cd /data/CentOS-6-x86_64/os/mirror*/pub/centos/6/os 

tar -cvf CentOS-6-x86_64.tar x86_64

mv CentOS-6-x86_64.tar /data/Tarballs/

