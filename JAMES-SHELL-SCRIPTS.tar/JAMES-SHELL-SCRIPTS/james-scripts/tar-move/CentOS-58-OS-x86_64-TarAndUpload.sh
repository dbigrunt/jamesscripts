#!/bin/bash

#Centos 5.8 OS tar 

cd /data/CentOS-5_8-x86_64/os/mirror*/pub/centos/5/os

tar -cvf CentOS-5_8-x86_64.tar x86_64

mv CentOS-5_8-x86_64.tar /data/Tarballs/

