#!/bin/bash

#First for epel5 x86_64
cd /data/epel-x86_64/epel-rhel5
rm -f *

cd /data/EPEL-repos/5/x86_64

find . -mtime -7 ! -name '*.html' | grep  .rpm | cut -b 1-2 --complement >> /data/epel-x86_64/epel-rhel5/updates-list

echo '===================================' >> /data/Scanned-Rpms-report
echo 'EPEL-repos 5 x86_64' >> /data/Scanned-Rpms-report
echo '===================================' >> /data/Scanned-Rpms-report

for i in $(cat /data/epel-x86_64/epel-rhel5/updates-list)
     do
        if clamscan $i
          then
           cp $i /data/epel-x86_64/epel-rhel5/
           echo '===================================' >> /data/Scanned-Rpms-report
           echo $i '  has been uploaded' >> /data/Scanned-Rpms-report
           echo '===================================' >> /data/Scanned-Rpms-report
         else
           echo '===================================' >> /data/Scanned-Rpms-report
           echo $i '  Failed Virus Scan' >> /data/Scanned-Rpms-report
           echo '===================================' >> /data/Scanned-Rpms-report
        fi
     done
  
    if ls /data/epel-x86_64/epel-rhel5/ | grep rpm
      then cd /data/epel-x86_64/ 
      tar -cvf epel-x86_64-rhel5.tar epel-rhel5
      chown owtuser1:owtuser1 epel-x86_64-rhel5.tar
      mv epel-x86_64-rhel5.tar /home/owt/priv/pickup
   fi
