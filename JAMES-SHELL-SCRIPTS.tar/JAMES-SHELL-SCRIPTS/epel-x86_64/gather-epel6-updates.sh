#!/bin/bash

#For epel6 x86_64

cd /data/epel-x86_64/epel-rhel6
rm -f *

cd /data/EPEL-repos/6/x86_64

find . -mtime -7 ! -name '*.html' | grep  .rpm | cut -b 1-2 --complement >> /data/epel-x86_64/epel-rhel6/updates-list

echo '===================================' >> /data/Scanned-Rpms-report
echo 'EPEL-repos 6 x86_64' >> /data/Scanned-Rpms-report
echo '===================================' >> /data/Scanned-Rpms-report

for i in $(cat /data/epel-x86_64/epel-rhel6/updates-list)
     do
        if clamscan $i
           then cp $i /data/epel-x86_64/epel-rhel6/
           echo '===================================' >> /data/Scanned-Rpms-report
           echo $i '  has been uploaded' >> /data/Scanned-Rpms-report
           echo '===================================' >> /data/Scanned-Rpms-report 
        else
        echo '===================================' >> /data/Scanned-Rpms-report
           echo $i '  Failed Virus Scan' >> /data/Scanned-Rpms-report
           echo '===================================' >> /data/Scanned-Rpms-report
        fi
     done
      if ls /data/epel-x86_64/epel-rhel6/ | grep rpm
         then cd /data/epel-x86_64/
         tar -cvf epel-x86_64-rhel6.tar epel-rhel6
         chown owtuser1:owtuser1 epel-x86_64-rhel6.tar
         mv epel-x86_64-rhel6.tar /home/owt/priv/pickup
      fi


