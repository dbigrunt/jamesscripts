#!/bin/bash

cd /data/EPEL-repos/5/x86_64/
\rm -rf debug
\rm -rf repoview

cd /data/EPEL-repos/6/x86_64/

\rm -rf debug
\rm -rf repoview

#cd /data/CentOS-repos/6/updates/x86_64/

#\rm -rf drpms
